/**
 * Seizoenstracker — GitHub Gist CORS Proxy
 * Cloudflare Worker
 */

const ALLOWED_ORIGIN = 'https://origindutch.github.io';

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const headers = corsHeaders(origin);

    // CORS preflight
    if (request.method === 'OPTIONS') {
      return new Response(null, { headers });
    }

    // Only allow from your GitHub Pages domain
    if (!origin.startsWith(ALLOWED_ORIGIN)) {
      return new Response('Forbidden', { status: 403, headers });
    }

    const url = new URL(request.url);

    // Strip leading slashes and match /gist or /gist/:id
    const path = url.pathname.replace(/^\/+/, '');
    const pathMatch = path.match(/^gist\/?(.*)$/);
    if (!pathMatch) {
      return new Response('Not found', { status: 404, headers });
    }

    const gistId = pathMatch[1].replace(/^\/+/, '');
    const githubUrl = gistId
      ? `https://api.github.com/gists/${gistId}`
      : 'https://api.github.com/gists';

    const githubResponse = await fetch(githubUrl, {
      method: request.method,
      headers: {
        'Authorization': request.headers.get('Authorization') || '',
        'Content-Type': 'application/json',
        'Accept': 'application/vnd.github+json',
        'X-GitHub-Api-Version': '2022-11-28',
        'User-Agent': 'Cambuur-Tracker-Worker',
      },
      body: request.method !== 'GET' ? await request.text() : undefined,
    });

    const body = await githubResponse.text();

    return new Response(body, {
      status: githubResponse.status,
      headers: {
        'Content-Type': 'application/json',
        ...headers,
      },
    });
  },
};

function corsHeaders(origin) {
  return {
    'Access-Control-Allow-Origin': origin || ALLOWED_ORIGIN,
    'Access-Control-Allow-Methods': 'GET, POST, PATCH, OPTIONS',
    'Access-Control-Allow-Headers': 'Authorization, Content-Type, Accept, X-GitHub-Api-Version',
    'Access-Control-Max-Age': '86400',
  };
}
